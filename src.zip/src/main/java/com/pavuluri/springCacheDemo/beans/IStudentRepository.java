/**
 * 
 */
package com.pavuluri.springCacheDemo.beans;

public interface IStudentRepository {
	Student getStudentById(String sId);
}
