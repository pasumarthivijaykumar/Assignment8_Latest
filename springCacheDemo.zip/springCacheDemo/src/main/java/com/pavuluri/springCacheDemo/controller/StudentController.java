/**
 * 
 */
package com.pavuluri.springCacheDemo.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pavuluri.springCacheDemo.beans.SlowStudentRepository;
import com.pavuluri.springCacheDemo.beans.Student;

@RestController
public class StudentController {

	@Autowired
	SlowStudentRepository sService;
	
	@PostMapping("/student")
	public String addStudent(@RequestBody Student student) {		
		SlowStudentRepository.getInstance().addStudent(student);		
		return "Added succesfully";		
	}
	
	@GetMapping("/student/{id}")
	public Student getStudentById(@PathVariable String id) {
		return SlowStudentRepository.getInstance().getStudentById(id);
	}
		
	@PutMapping("/student")
	public Student updateStudent(@RequestBody Student student) {
		return SlowStudentRepository.getInstance().updateStudent(student);		
	}
	
	@DeleteMapping("/student/all")
	public String deleteAll() {
		return SlowStudentRepository.getInstance().deleteStudentsFromMapAndCache();		
	}
	
	@DeleteMapping("/student/cache")
	public String deleteCache() {
		return SlowStudentRepository.getInstance().deleteStudentsFromCacheOnly();		
	}
	
	@DeleteMapping("/student/{id}")
	public String deleteStudentById(@PathVariable String id) {
		return SlowStudentRepository.getInstance().deleteStudentByIdFromCacheAndMap(id);	
	}
	
	@PutMapping("/config/delay")
	public String configDelay(@RequestBody Map<String, Object> configValue) {
		int value = (Integer)configValue.get("value");
		
		return SlowStudentRepository.getInstance().configDelay(Long.valueOf(value));		
	}
}
