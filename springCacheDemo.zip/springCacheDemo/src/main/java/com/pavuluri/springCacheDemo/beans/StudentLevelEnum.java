/**
 * 
 */
package com.pavuluri.springCacheDemo.beans;

public enum StudentLevelEnum {

	freshman ("freshman"), 
	sophomore ("sophomore"), 
	junior ("junior"), 
	senior ("senior");
	
	private String acdemicLevel;
	
	StudentLevelEnum(String acLevel){
		this.acdemicLevel = acLevel;
	}
	
	public String getAcLevel() {
		return acdemicLevel;
	}
}
